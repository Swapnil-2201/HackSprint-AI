// src/app/idea/IdeaAnalyzer.jsx

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  BrainCircuit,
  Sparkles,
  Rocket,
  Loader2,
} from "lucide-react";
import toast from "react-hot-toast";

import IdeaForm from "./IdeaForm";
import Button from "@components/shared/Button";

const IdeaAnalyzer = () => {
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);

  const [idea, setIdea] = useState({
    title: "",
    domain: "",
    problem: "",
    solution: "",
    technologies: "",
    targetUsers: "",
  });

  const handleChange = (e) => {
    setIdea((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleAnalyze = async (e) => {
    e.preventDefault();

    if (
      !idea.title ||
      !idea.problem ||
      !idea.solution
    ) {
      toast.error("Please complete the required fields.");
      return;
    }

    try {
      setLoading(true);

      // TODO:
      // Replace with backend API
      await new Promise((resolve) =>
        setTimeout(resolve, 2000)
      );

      toast.success("Idea analyzed successfully!");

      navigate("/idea/result");
    } catch (error) {
      toast.error("Analysis failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">

      {/* Hero */}

      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-700 p-8 text-white shadow-xl">

        <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-white/10 blur-3xl"></div>

        <div className="absolute -bottom-24 left-0 h-56 w-56 rounded-full bg-cyan-400/10 blur-3xl"></div>

        <div className="relative z-10">

          <div className="mb-5 inline-flex items-center gap-2 rounded-full bg-white/20 px-4 py-2 backdrop-blur">

            <BrainCircuit size={18} />

            AI Powered Idea Analyzer

          </div>

          <h1 className="text-4xl font-bold">
            Analyze Your Project Idea
          </h1>

          <p className="mt-4 max-w-3xl text-blue-100">
            Let AI evaluate your hackathon idea based on
            innovation, feasibility, scalability, competition,
            market demand and technical complexity.
          </p>

        </div>

      </div>

      {/* Features */}

      <div className="grid gap-5 md:grid-cols-3">

        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-900">

          <Sparkles className="mb-4 text-yellow-500" />

          <h3 className="font-bold text-lg">
            Innovation Score
          </h3>

          <p className="mt-2 text-sm text-slate-500">
            AI evaluates uniqueness and creativity.
          </p>

        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-900">

          <Rocket className="mb-4 text-blue-600" />

          <h3 className="font-bold text-lg">
            Feasibility
          </h3>

          <p className="mt-2 text-sm text-slate-500">
            Checks implementation difficulty and timeline.
          </p>

        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-900">

          <BrainCircuit className="mb-4 text-purple-600" />

          <h3 className="font-bold text-lg">
            AI Suggestions
          </h3>

          <p className="mt-2 text-sm text-slate-500">
            Receive recommendations to improve your project.
          </p>

        </div>

      </div>

      {/* Form */}

      <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-sm dark:border-slate-700 dark:bg-slate-900">

        <div className="mb-8">

          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
            Project Information
          </h2>

          <p className="mt-2 text-slate-500">
            Fill in the project details for AI analysis.
          </p>

        </div>

        <form
          onSubmit={handleAnalyze}
          className="space-y-8"
        >
          <IdeaForm
            formData={idea}
            onChange={handleChange}
          />

          <Button
            type="submit"
            loading={loading}
            className="w-full"
          >
            {loading ? (
              <>
                <Loader2
                  size={18}
                  className="animate-spin"
                />
                Analyzing Idea...
              </>
            ) : (
              <>
                <BrainCircuit size={18} />
                Analyze Idea
              </>
            )}
          </Button>
        </form>

      </div>

    </div>
  );
};

export default IdeaAnalyzer;