// src/app/dashboard/ActivityTimeline.jsx

import {
  CheckCircle2,
  FolderPlus,
  Rocket,
  AlertTriangle,
  Brain,
} from "lucide-react";

const activities = [
  {
    id: 1,
    title: "Project Created",
    description: "HackSprint AI Coach project initialized.",
    time: "2 mins ago",
    icon: FolderPlus,
    color: "bg-blue-500",
  },
  {
    id: 2,
    title: "Idea Analysis Completed",
    description: "AI analyzed your project idea successfully.",
    time: "18 mins ago",
    icon: Brain,
    color: "bg-purple-500",
  },
  {
    id: 3,
    title: "Roadmap Generated",
    description: "Development roadmap has been generated.",
    time: "45 mins ago",
    icon: Rocket,
    color: "bg-green-500",
  },
  {
    id: 4,
    title: "Risk Report Updated",
    description: "Two new potential risks were detected.",
    time: "1 hour ago",
    icon: AlertTriangle,
    color: "bg-yellow-500",
  },
  {
    id: 5,
    title: "Checklist Completed",
    description: "Frontend setup marked as completed.",
    time: "Yesterday",
    icon: CheckCircle2,
    color: "bg-emerald-500",
  },
];

const ActivityTimeline = () => {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-900">

      {/* Header */}

      <div className="mb-8 flex items-center justify-between">

        <div>

          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            Recent Activity
          </h2>

          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Latest updates from your hackathon workspace.
          </p>

        </div>

      </div>

      {/* Timeline */}

      <div className="relative ml-3 border-l-2 border-slate-200 dark:border-slate-700">

        {activities.map((activity) => {
          const Icon = activity.icon;

          return (
            <div
              key={activity.id}
              className="relative mb-8 pl-10 last:mb-0"
            >
              {/* Timeline Icon */}

              <div
                className={`absolute -left-5 flex h-10 w-10 items-center justify-center rounded-full text-white shadow-md ${activity.color}`}
              >
                <Icon size={18} />
              </div>

              {/* Card */}

              <div className="rounded-xl border border-slate-200 bg-slate-50 p-5 transition-all hover:shadow-md dark:border-slate-700 dark:bg-slate-800">

                <div className="flex items-center justify-between">

                  <h3 className="font-semibold text-slate-900 dark:text-white">
                    {activity.title}
                  </h3>

                  <span className="text-xs text-slate-500">
                    {activity.time}
                  </span>

                </div>

                <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
                  {activity.description}
                </p>

              </div>

            </div>
          );
        })}

      </div>

    </div>
  );
};

export default ActivityTimeline;