// src/app/dashboard/DashboardCards.jsx

import {
  FolderKanban,
  CheckCircle2,
  BrainCircuit,
  AlertTriangle,
  ArrowUpRight,
} from "lucide-react";

const cards = [
  {
    id: 1,
    title: "Total Projects",
    value: "12",
    change: "+2 this week",
    icon: FolderKanban,
    color: "bg-blue-500",
    bg: "bg-blue-50 dark:bg-blue-900/20",
  },
  {
    id: 2,
    title: "Tasks Completed",
    value: "84%",
    change: "+8% this week",
    icon: CheckCircle2,
    color: "bg-green-500",
    bg: "bg-green-50 dark:bg-green-900/20",
  },
  {
    id: 3,
    title: "AI Analyses",
    value: "37",
    change: "+5 today",
    icon: BrainCircuit,
    color: "bg-purple-500",
    bg: "bg-purple-50 dark:bg-purple-900/20",
  },
  {
    id: 4,
    title: "Risk Alerts",
    value: "4",
    change: "2 High Priority",
    icon: AlertTriangle,
    color: "bg-yellow-500",
    bg: "bg-yellow-50 dark:bg-yellow-900/20",
  },
];

const DashboardCards = () => {
  return (
    <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-4">
      {cards.map((card) => {
        const Icon = card.icon;

        return (
          <div
            key={card.id}
            className="group rounded-2xl border border-slate-200 bg-white p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl dark:border-slate-700 dark:bg-slate-900"
          >
            {/* Top */}

            <div className="flex items-center justify-between">
              <div
                className={`flex h-14 w-14 items-center justify-center rounded-xl ${card.bg}`}
              >
                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-lg text-white ${card.color}`}
                >
                  <Icon size={22} />
                </div>
              </div>

              <ArrowUpRight
                size={20}
                className="text-slate-400 transition group-hover:text-blue-600"
              />
            </div>

            {/* Body */}

            <div className="mt-6">
              <p className="text-sm text-slate-500 dark:text-slate-400">
                {card.title}
              </p>

              <h2 className="mt-2 text-3xl font-bold text-slate-900 dark:text-white">
                {card.value}
              </h2>

              <p className="mt-3 text-sm font-medium text-green-600">
                {card.change}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default DashboardCards;