import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";

import App from "./App";

import { ThemeProvider } from "./context/ThemeContext";   // or ./contexts/ThemeContext
import { AuthProvider } from "./context/AuthContext";     // or ./contexts/AuthContext

import "./styles/variables.css";
import "./styles/global.css";
import "./styles/layout.css";
import "./styles/typography.css";
import "./styles/buttons.css";
import "./styles/cards.css";
import "./styles/forms.css";
import "./styles/themes.css";
import "./styles/utilities.css";
import "./styles/animations.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <BrowserRouter>
    <ThemeProvider>
      <AuthProvider>
        <App />
      </AuthProvider>
    </ThemeProvider>
  </BrowserRouter>
);