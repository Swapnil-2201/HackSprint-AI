import api from "./api";

const aiService = {
  // Analyze Project Idea
  async analyzeIdea(payload) {
    const { data } = await api.post(
      "/ai/idea-analyzer",
      payload
    );

    return data;
  },

  // Generate Project Roadmap
  async generateRoadmap(payload) {
    const { data } = await api.post(
      "/ai/roadmap",
      payload
    );

    return data;
  },

  // Generate Risk Report
  async generateRiskReport(payload) {
    const { data } = await api.post(
      "/ai/risk-report",
      payload
    );

    return data;
  },

  // Generate Development Checklist
  async generateChecklist(payload) {
    const { data } = await api.post(
      "/ai/checklist",
      payload
    );

    return data;
  },

  // Generate Pitch Deck / Presentation
  async generatePitch(payload) {
    const { data } = await api.post(
      "/ai/pitch-generator",
      payload
    );

    return data;
  },

  // AI Chat Assistant
  async chat(payload) {
    const { data } = await api.post(
      "/ai/chat",
      payload
    );

    return data;
  },

  // Generate Project Summary
  async generateSummary(payload) {
    const { data } = await api.post(
      "/ai/summary",
      payload
    );

    return data;
  },

  // Generate Tech Stack Suggestions
  async suggestTechStack(payload) {
    const { data } = await api.post(
      "/ai/tech-stack",
      payload
    );

    return data;
  },

  // Generate Feature Suggestions
  async suggestFeatures(payload) {
    const { data } = await api.post(
      "/ai/features",
      payload
    );

    return data;
  },

  // Generate Team Roles
  async generateTeamRoles(payload) {
    const { data } = await api.post(
      "/ai/team-roles",
      payload
    );

    return data;
  },
};

export default aiService;